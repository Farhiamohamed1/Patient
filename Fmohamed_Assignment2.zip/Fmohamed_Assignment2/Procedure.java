import java.time.LocalDate; // Import the LocalDate class from the java.time package

public class Procedure {
    // Declare fields for the name, date, practitioner, and charges of a medical procedure
    private String name;
    private LocalDate date;
    private String practitioner;
    private double charges;

    // Create a no-arg constructor
    public Procedure() {
    }

    // Create a parameterized constructor that initializes the name and date
    public Procedure(String name, LocalDate date) {
        this.name = name;
        this.date = date;
    }

    // Create a parameterized constructor that initializes all attributes
    public Procedure(String name, LocalDate date, String practitioner, double charges) {
        this.name = name;
        this.date = date;
        this.practitioner = practitioner;
        this.charges = charges;
    }

    // Create accessors and mutators for each attribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getPractitioner() {
        return practitioner;
    }

    public void setPractitioner(String practitioner) {
        this.practitioner = practitioner;
    }

    public double getCharges() {
        return charges;
    }

    public void setCharges(double charges) {
        this.charges = charges;
    }

    // Override the toString method to display all information of a procedure
    @Override
    public String toString() {
        return "Procedure{" +
                "name='" + name + '\'' +
                ", date=" + date +
                ", practitioner='" + practitioner + '\'' +
                ", charges=" + charges +
                '}';
    }
}
