/*
* Class: CMSC203
* Instructor: Ahmed Tarek
* Description : For this program I have to create a program that
has 3 different classes. One class is named Patients, the second 
is named Procedure, and the last one is named PatientDriverApp.
* Due: 2/20/2024
 * Platform/compiler: Eclipse
* I pledge that I have completed the programming 
 * Assignment independently. I have not copied the code. 
 * From a student or any source. I have not given my code. 
 * To any student.
 Print your Name here: Farhia Mohamed
*/
import java.time.LocalDate;
public class PatientDriverApp {

    public static void main(String[] args) {
        // Create a new patient
        Patient patient = new Patient("Rachel", "Stewert", "Cliff", "193 Silver St", "Los Angeles", "CA", "19335", "213-3015-20214", "Ivanka Consuela", "555-555-5555");

        // Create three procedures
        Procedure procedure1 = new Procedure("Procedure 1", LocalDate.of(2024, 2, 12));
        procedure1.setPractitioner("Dr. Jerry");
        procedure1.setCharges(196.0);

        Procedure procedure2 = new Procedure("Procedure 2", LocalDate.of(2020, 11, 13), "Dr. Marshall", 476.0);

        Procedure procedure3 = new Procedure("Procedure 3", LocalDate.of(2014, 5, 16), "Dr. chen", 975.0);

        // Display patient information
        displayPatient(patient);

        // Display procedure information
        displayProcedure(procedure1);
        
        displayProcedure(procedure2);
        
        displayProcedure(procedure3);

        // Calculate total charges
        double totalCharges = calculateTotalCharges(procedure1, procedure2, procedure3);

        // Display total charges
        System.out.printf("Total charges: $%,.2f%n", totalCharges);
    	String Studentname = "Farhia Mohamed";
		String MC = "21109663";
		String DueDate = "02/20/2024";
		System.out.println("Name: " + Studentname);
		System.out.println("MC#: " + MC);
		System.out.println("Due Date: " + DueDate);

    }

    public static void displayPatient(Patient patient) {
        System.out.println("Patient information:");
        System.out.println("Full name: " + patient.buildFullName());
        System.out.println("Address: " + patient.buildAddress());
        System.out.println("Phone number: " + patient.getPhoneNumber());
        System.out.println("Emergency contact: " + patient.buildEmergencyContact());
        System.out.println();
    }

    public static void displayProcedure(Procedure procedure) {
        System.out.println("Procedure information:");
        System.out.printf("Name: %s%n", procedure.getName());
        System.out.printf("Date: %s%n", procedure.getDate());
        System.out.printf("Practitioner: %s%n", procedure.getPractitioner());
        System.out.printf("Charges: $%,.2f%n", procedure.getCharges());
        System.out.println();
    }


    public static double calculateTotalCharges(Procedure procedure1, Procedure procedure2, Procedure procedure3) {
        return procedure1.getCharges() + procedure2.getCharges() + procedure3.getCharges();
     
    }
  
}
